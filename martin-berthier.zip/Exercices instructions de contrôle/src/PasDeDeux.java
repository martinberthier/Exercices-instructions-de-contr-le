
public class PasDeDeux {

	public static void main(String[] args) {
		
	
		for(int i=10; i<500; i=i+2){
			
		}
	}

}
	
