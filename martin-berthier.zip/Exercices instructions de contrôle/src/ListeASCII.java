
public class ListeASCII {

	public static void main(String[] args) {
		
//		for (int i = 0; i<127; i++) {
//			System.out.println(i+" = "+(char)i);
//		}
		
		int compteur=1;
		while (compteur < 127){
			System.out.println(compteur+" = "+(char)compteur);
			compteur++;
		}
		
	}

}
